// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Form interaction improvements
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        const submitButton = this.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.innerHTML = 'Processing...';
            submitButton.classList.add('processing');
        }
    });
});

// Intersection Observer for scroll animations
const observerOptions = {
    threshold: 0.1
};

const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.animate-on-scroll').forEach(el => {
    observer.observe(el);
});

// Button hover animations
document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateY(-2px)';
    });
    button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateY(0)';
    });
});

// Initialize starry night effect
const starsContainer = document.createElement('div');
starsContainer.className = 'stars';
document.querySelector('.header').appendChild(starsContainer);

// Initialize chart animations
document.querySelectorAll('.chart-container canvas').forEach(chart => {
    chart.style.opacity = 0;
    setTimeout(() => {
        chart.style.transition = 'opacity 1s ease';
        chart.style.opacity = 1;
    }, 500);
});

// Chart.js initialization
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('resultsChart').getContext('2d');
    const modelNames = JSON.parse(document.getElementById('modelNames').textContent);
    const r2Scores = JSON.parse(document.getElementById('r2Scores').textContent);
    const accuracies = JSON.parse(document.getElementById('accuracies').textContent);

    const resultsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: modelNames,
            datasets: [{
                label: 'R2 Score',
                data: r2Scores,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }, {
                label: 'Accuracy (%)',
                data: accuracies,
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
});
