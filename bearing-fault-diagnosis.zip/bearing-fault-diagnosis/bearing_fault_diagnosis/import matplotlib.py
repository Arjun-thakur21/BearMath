import matplotlib.pyplot as plt
import os

def generate_plots():
    # Example data, replace with actual analysis results
    rmse_data = [1.2, 0.8, 0.5]
    accuracy_data = [95, 90, 85]

    # Ensure the static/plots directory exists
    os.makedirs('static/plots', exist_ok=True)

    # Generate RMSE plot
    plt.figure()
    plt.plot(rmse_data)
    plt.title('Model RMSE')
    plt.savefig('static/plots/rmse.png')

    # Generate accuracy pie chart
    plt.figure()
    plt.pie(accuracy_data, labels=['Model 1', 'Model 2', 'Model 3'], autopct='%1.1f%%')
    plt.title('Bearing Fault Diagnosis Accuracy')
    plt.savefig('static/plots/bearing_accuracy_pie.png')

    # Generate model-wise accuracy pie chart
    plt.figure()
    plt.pie(accuracy_data, labels=['Model 1', 'Model 2', 'Model 3'], autopct='%1.1f%%')
    plt.title('Model-wise Bearing Fault Diagnosis Accuracy')
    plt.savefig('static/plots/model_accuracy_pie.png')

generate_plots()