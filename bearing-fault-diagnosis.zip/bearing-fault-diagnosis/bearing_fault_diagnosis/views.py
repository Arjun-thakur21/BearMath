from django.shortcuts import render
from django.http import HttpResponse
from .data_analysis import analyze_and_train
import pandas as pd
import logging
from diagnosis.models import Contact

logger = logging.getLogger(__name__)

def index(request):
    return render(request, 'index.html')

def savecontact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        en = Contact(name=name, email=email, message=message)
        en.save()
    return render(request, 'index.html')

def diagnose(request):
    logger.info("Diagnosis function called")  # Log when the function is called

    if request.method == 'POST':
        uploaded_file = request.FILES.get('inputFile')  # Get the uploaded file

        if not uploaded_file:
            logger.error("No file uploaded")
            return HttpResponse("No file uploaded")

        file_extension = uploaded_file.name.split('.')[-1].lower()
        logger.info(f"Uploaded file extension: {file_extension}")  # Log the file extension

        try:
            if file_extension == 'xlsx':
                df = pd.read_excel(uploaded_file, engine='openpyxl')
            elif file_extension == 'xls':
                df = pd.read_excel(uploaded_file, engine='xlrd')
            else:
                logger.error("Invalid file format")
                return HttpResponse("Invalid file format")
        except Exception as e:
            logger.error(f"Error reading the file: {e}")
            return HttpResponse(f"Error reading the file: {e}")

        logger.info(f"DataFrame structure: {df.head()}")  # Log the structure of the DataFrame

        try:
            table_rows, model_names, r2_scores, accuracies = analyze_and_train(df)
        except Exception as e:
            logger.error(f"Error during analysis: {e}")
            return HttpResponse(f"Error during analysis: {e}")

        context = {
            'table_rows': table_rows,
            'model_names': model_names,
            'r2_scores': r2_scores,
            'accuracies': accuracies,
        }

        return render(request, 'diagnosis_result.html', context)

    return HttpResponse("Invalid request")
